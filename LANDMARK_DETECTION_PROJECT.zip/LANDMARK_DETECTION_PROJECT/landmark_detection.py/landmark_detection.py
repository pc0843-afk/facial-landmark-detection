import cv2

# Load image
img = cv2.imread("face.jpg")

# Resize image (important)
img = cv2.resize(img, (700, 700))

# Convert to gray
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Load cascade
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades +
    "haarcascade_frontalface_default.xml"
)

# Detect face
faces = face_cascade.detectMultiScale(
    gray,
    scaleFactor=1.05,
    minNeighbors=3,
    minSize=(30, 30)
)

print("Detected:", faces)

# Draw rectangle
for (x, y, w, h) in faces:

    cv2.rectangle(
        img,
        (x, y),
        (x+w, y+h),
        (0, 255, 0),
        3
    )

    # Landmark point
    center_x = x + w//2
    center_y = y + h//2

    cv2.circle(
        img,
        (center_x, center_y),
        6,
        (0, 0, 255),
        -1
    )

# Show image
cv2.imshow("Detection", img)

cv2.waitKey(0)
cv2.destroyAllWindows()